<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<h4 style="color:grey; font-family:Allura;"><strong>[IF635] Web Programming</strong></h4>
		</div>
		<ul class="nav navbar-nav navbar-right" style="padding:0 5%">
			<li class="active">
				<a href="#">Employees</a>
			</li>
		</ul>
	</div>
</nav>